export interface newsList{
    key?:string;
    name:string;
    comments:string;
}