export interface needsList{
    key?:string;
    name:string;
    no:string;
    comments:string;
}