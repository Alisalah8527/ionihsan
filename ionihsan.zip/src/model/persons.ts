export interface personsList{
    key?:string;
    name:string;
    sex:string;
    age:string;
    province:string;
    comments:string;
}