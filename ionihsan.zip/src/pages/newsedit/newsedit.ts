import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import {NewsproviderProvider } from '../../providers/newsprovider/newsprovider';
import { HomePage } from '../home/home';
/**
 * Generated class for the NewseditPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-newsedit',
  templateUrl: 'newsedit.html',
})
export class NewseditPage {
  edit = {
    key : '',
    name : '',
    comments:'',
} 

  constructor(public navCtrl: NavController, public navParams: NavParams,  public addnewsServiceProvider:NewsproviderProvider) {
   
    console.log(this.edit.name)
    this.edit.key=this.navParams.get('key')
     this.edit.name=this.navParams.get('name')
     this.edit.comments=this.navParams.get('comments')
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad NewseditPage');
  }
  updatenews1(newsf){
    this.addnewsServiceProvider.updatenews(newsf).then(()=>{
    this.navCtrl.setRoot(HomePage)  
    console.log('update')
  })}

  cancel(){
    this.navCtrl.pop();
  }
  updaten(key , name, comments ){
    this.edit.key = key
    this.edit.name =name
    this.edit.comments= comments

    this.updatenews1(this.edit)  
    
  }

}



