import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { NewseditPage } from './newsedit';

@NgModule({
  declarations: [
    NewseditPage,
  ],
  imports: [
    IonicPageModule.forChild(NewseditPage),
  ],
})
export class NewseditPageModule {}
