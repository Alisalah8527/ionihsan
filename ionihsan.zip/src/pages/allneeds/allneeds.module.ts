import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AllneedsPage } from './allneeds';

@NgModule({
  declarations: [
    AllneedsPage,
  ],
  imports: [
    IonicPageModule.forChild(AllneedsPage),
  ],
})
export class AllneedsPageModule {}
