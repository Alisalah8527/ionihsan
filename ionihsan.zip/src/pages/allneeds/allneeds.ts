import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams , AlertController } from 'ionic-angular';
import { needsList } from '../../model/needs';
import { AddneedServiceProvider } from '../../providers/addneed-service/addneed-service';
import { AngularFireDatabase , AngularFireObject } from 'angularfire2/database';
import { HomePage } from '../home/home';
import { NeedseditPage } from '../needsedit/needsedit';
import { NeedsdetailsPage } from '../needsdetails/needsdetails';


// import { NeedsdetailsPage } from '../needsdetails/needsdetails';


@IonicPage()
@Component({
  selector: 'page-allneeds',
  templateUrl: 'allneeds.html',
})
export class AllneedsPage {
  
 needsList :AngularFireObject<any>
 needsf:needsList={
    key:'',
    name:'',
    no:'',
    comments:''
  }
  itemArray= [];
  myObject=[];
  myObjectfinal=[];

  private adminLoggedIn :boolean=false;

  constructor(public navCtrl: NavController, 
              public navParams: NavParams ,
              public alertCtrl: AlertController ,
              public addneedServiceProvider: AddneedServiceProvider ,
              public db:AngularFireDatabase ) {


                 let adminstatus = localStorage.getItem('adminLoggedIn')
                 // console.log(adminstatus)
                 if (adminstatus === 'true') {
                 this.adminLoggedIn = true;
                 }else{
                 this.adminLoggedIn = false;
                }
                this.needsList=db.object('needs');
               
                this.needsList.snapshotChanges().subscribe(action=>{
               
                  if (action.payload.val()==null || action.payload.val()== undefined) {
                    console.log('No Data')
                  } else {  
               
                this.itemArray.push(action.payload.val() as needsList)
                
                console.log(this.itemArray[0])
                this.myObject = Object.entries(this.itemArray[0])
              
                this.myObjectfinal=this.myObject;
                  }
                })
              
              
              }
  ionViewDidLoad() {
    console.log('ionViewDidLoad AllneedsPage');
  }

  updateneeds(needslist:needsList){
    this.addneedServiceProvider.updateneeds(needslist).then(()=>{
    this.navCtrl.setRoot(HomePage)  
    console.log('update')
  })}
    removeneeds(needslist){
      this.addneedServiceProvider.removeneeds(needslist).then(()=>{
        this.navCtrl.setRoot(HomePage)
        console.log('delete')
      })}

      needd(key,name,no,comments){
        this.navCtrl.push(NeedsdetailsPage,{
          key:key,
          name:name,
          no:no,
          comments:comments,
        })
      }

      details(key , name, no, comments){
        let prompt = this.alertCtrl.create({
          title:'التفاصيل',
          message : 'بيانات الاحتياج',
          inputs:[{name : 'name',
                  value : name},

                  {name : 'no',
                  value : no},

                  {name : 'comments',
                  value : comments},
                 ],
                buttons:[
                {text:'رجوع',
                handler : data =>{
                console.log('cancel clicked');
              }
            },
    
    
          ]
        });
    
       prompt.present();
    
    
      }
      needse(key,name,no,comments){
        this.navCtrl.push(NeedseditPage,{
          key:key,
          name:name,
          no:no,
          comments:comments,
        })
      }
  edit( key , name , no , comments ) {
    let prompt = this.alertCtrl.create({
      title: 'تعديل الاحتياج',
      message: "تعديل بيانات الاحتياج الحالية",
      inputs: [
        {
          name: 'name',
          value:name
        },
        {
          name: 'no',
          value: no
        },
        {
          name: 'comments',
          value: comments
        },
      ],
      buttons: [
        {
          text: 'الغاء',
          handler: data => {
            console.log('Cancel clicked');
          }
        },
        {
          text: 'حفظ',
          handler: data => {
        //    console.log('');
             this.needsf.name=data.name
             this.needsf.no=data.no
             this.needsf.comments=data.comments
             this.needsf.key=key
             this.updateneeds(this.needsf)
          }
        }
      ]
    });
    prompt.present();
  }



}
