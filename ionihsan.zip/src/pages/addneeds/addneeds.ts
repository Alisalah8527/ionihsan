import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams , AlertController } from 'ionic-angular';
import { needsList } from '../../model/needs';
import { AddneedServiceProvider } from '../../providers/addneed-service/addneed-service'
import { HomePage } from '../home/home';
/**
 * Generated class for the AddneedsPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-addneeds',
  templateUrl: 'addneeds.html',
})
export class AddneedsPage {



  needs:needsList={
    name:'',
    no:'',
    comments:''
  }
  constructor(public navCtrl: NavController, 
              public navParams: NavParams,
              public alertCtrl: AlertController,
              public addneedServiceProvider:AddneedServiceProvider) {
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad AddneedsPage');
  }
  addne(needs:needsList){
    this.addneedServiceProvider.addneeds(needs).then(ref=>{
    this.showAlert()
    this.navCtrl.push(HomePage)
    })
   }
 
   showAlert() {
     const alert = this.alertCtrl.create({
       title: 'اضافة',
       subTitle: 'شكرا لكم لقد تمت عملية الاضافة بنجاح',
       buttons: ['OK']
     });
 
   }



}
