import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AddneedsPage } from './addneeds';

@NgModule({
  declarations: [
    AddneedsPage,
  ],
  imports: [
    IonicPageModule.forChild(AddneedsPage),
  ],
})
export class AddneedsPageModule {}
