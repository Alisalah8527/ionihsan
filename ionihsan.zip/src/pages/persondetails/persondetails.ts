import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';

/**
 * Generated class for the PersondetailsPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-persondetails',
  templateUrl: 'persondetails.html',
})
export class PersondetailsPage {
  persond={
  key:'',
  name:'',
  sex:'',
  age:'',
  province:'',
  comments:''
  }
  constructor(public navCtrl: NavController, public navParams: NavParams) {
      
    this.persond.key=this.navParams.get('key')
    this.persond.name=this.navParams.get('name')
    this.persond.sex=this.navParams.get('sex')
    this.persond.age=this.navParams.get('age')
    this.persond.province=this.navParams.get('province')
    this.persond.comments=this.navParams.get('comments')
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad PersondetailsPage');
  }

}
