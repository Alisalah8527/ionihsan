import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { PersondetailsPage } from './persondetails';

@NgModule({
  declarations: [
    PersondetailsPage,
  ],
  imports: [
    IonicPageModule.forChild(PersondetailsPage),
  ],
})
export class PersondetailsPageModule {}
