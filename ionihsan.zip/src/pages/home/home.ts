import { Component } from '@angular/core';
import { NavController , AlertController} from 'ionic-angular';
import { AngularFireAuth } from 'angularfire2/auth';
import { AddneedsPage }from '../addneeds/addneeds';
import { AddpersonsPage }from '../addpersons/addpersons';
import { AllpersonsPage }from '../allpersons/allpersons';
import { NewsPage }from '../news/news';
import { AllneedsPage }from'../allneeds/allneeds';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {


  email:string ='';
  password:string = '';
  private adminLoggedIn :boolean=false;

  constructor(public navCtrl: NavController , 
              public fire:AngularFireAuth , 
              public alertCtrl:AlertController) {
    let adminstatus = localStorage.getItem('adminLoggedIn')
    console.log(adminstatus)
    if (adminstatus === 'true') {
      this.adminLoggedIn = true;
    }else{
      this.adminLoggedIn = false;
    }
  }
  goToAllOldPersonlPage(){
    this.navCtrl.push(AllpersonsPage)
console.log('goToAllOldPersonlPage')
  }
  goToNeedsPage(){
    this.navCtrl.push(AllneedsPage)
    console.log('goToNeedsPage')
  }
  goToNewsPage(){
    this.navCtrl.push(NewsPage)
    console.log('goToNewsPage')
  }
  goToAddNeedsPage(){
    this.navCtrl.push(AddneedsPage)
    console.log('goToAddNeedsPage')
  }
  goToAddPersonsPage(){
    this.navCtrl.push(AddpersonsPage)
    console.log('goToAddPersonPage')
  }

logout(){
  this.fire.auth.signOut();
  localStorage.setItem('adminLoggedIn','false')
  let adminstatus = localStorage.getItem('adminLoggedIn')
  this.navCtrl.setRoot(HomePage)
  // console.log(adminstatus)
  
}


logIn(){
  this.fire.auth.signInWithEmailAndPassword(this.email, this.password)
  .then(user =>{
 
  
   if (this.email==='admin@gmail.com') {
     this.adminLoggedIn=true;
     localStorage.setItem('adminLoggedIn','true')
     
     
   }else{
    localStorage.setItem('adminLoggedIn','false')
    this.showAlert()
    this.navCtrl.setRoot(HomePage)
    
   }
   
    this.navCtrl.setRoot(HomePage)
        }).catch(error =>{
        console.error(error)
        this.showAlert()
         this.navCtrl.setRoot(HomePage)
  })
  
  }

  showAlert() {
    const alert = this.alertCtrl.create({
      subTitle: ' لطفا انت لست المسؤول , لست بحاجة لأن تعمل تسجيل دخول يمكنك التصفح بدون تسجيل الدخول',
      buttons: ['OK']
    });
    alert.present();
  }








}
