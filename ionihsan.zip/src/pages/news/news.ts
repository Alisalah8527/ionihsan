import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, AlertController } from 'ionic-angular';
import { AngularFireDatabase , AngularFireObject } from 'angularfire2/database';
import {NewsproviderProvider } from '../../providers/newsprovider/newsprovider';
import { newsList } from '../../model/news';
import { HomePage } from '../home/home';
import { NewsdetailsPage } from '../newsdetails/newsdetails'
import { NewseditPage } from '../newsedit/newsedit'
/**
 * Generated class for the NewsPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-news',
  templateUrl: 'news.html',
})
export class NewsPage {
  newsList :AngularFireObject<any>
 newsf:newsList={
    key:'',
    name:'',
    comments:''
  }
  itemArray= [];
  myObject=[];
  myObjectfinal=[];
  private adminLoggedIn :boolean=false;

  constructor(public navCtrl: NavController, 
              public navParams: NavParams ,
              public alertCtrl: AlertController ,
              public addnewsServiceProvider:NewsproviderProvider ,
              public db:AngularFireDatabase ) {


              let adminstatus = localStorage.getItem('adminLoggedIn')
              // console.log(adminstatus)
              if (adminstatus === 'true') {
                this.adminLoggedIn = true;
              }else{
                this.adminLoggedIn = false;
              }
              
              this.newsList=db.object('News');
               
              this.newsList.snapshotChanges().subscribe(action=>{
             
                if (action.payload.val()==null || action.payload.val()== undefined) {
                  console.log('No Data')
                } else {  
             
              this.itemArray.push(action.payload.val() as newsList)
              
              console.log(this.itemArray[0])
              this.myObject = Object.entries(this.itemArray[0])
            
              this.myObjectfinal=this.myObject;
                }
              })
            
            }

  ionViewDidLoad() {
    console.log('ionViewDidLoad NewsPage');
  }



  updatenews1(newsf){
    this.addnewsServiceProvider.updatenews(newsf).then(()=>{
    this.navCtrl.setRoot(HomePage)  
    console.log('update')
  })}

  updaten(key,name,comments){
    this.navCtrl.push(NewseditPage,{
      key:key,
      name:name,
      comments:comments,
    }) 
  }
  removenews(newsf){
      this.addnewsServiceProvider.removenewss(newsf).then(()=>{
        this.navCtrl.pop()
        console.log('delete')
      })}

      detailsn(key,name,comments){
        this.navCtrl.push(NewsdetailsPage,{
          key:key,
          name:name,
          comments:comments,
        }) 
       
      }


  details(key , name, comments){
    let prompt = this.alertCtrl.create({
      title:'التفاصيل',
      
      inputs:[{name : 'name',
              value : name},

              {name : 'comments',
              value : comments},
             ],
            buttons:[
            {text:'رجوع',
            handler : data =>{
            console.log('cancel clicked');
          }
        },


      ]
    });

   prompt.present();


  }

  update( key , name ,  comments ) {
   let prompt = this.alertCtrl.create({
      title: 'تعديل الاخبار والاعلانات',
      inputs: [{name: 'name',
                value:name},

               {name: 'comments',
                value: comments},],
  buttons: [{
      text: 'الغاء',
      handler: data => {
        console.log('Cancel clicked');
      }
    },
    {
      text: 'حفظ',
      handler: data => {
    //    console.log('');
         this.newsf.name=data.name
         this.newsf.comments=data.comments
         this.newsf.key=key
         this.updatenews1(this.newsf)
      }
    }
  ]
});
prompt.present();
}











}
