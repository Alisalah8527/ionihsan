import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams , AlertController } from 'ionic-angular';
import { AngularFireDatabase , AngularFireObject } from 'angularfire2/database';
import { HomePage } from '../home/home';
import { PersondetailsPage } from '../persondetails/persondetails';
import { PersonupdatePage } from '../personupdate/personupdate';

// import { HomePage } from '../home/home';

import { AddpersonsServiceProvider } from '../../providers/addpersons-service/addpersons-service';
import { personsList } from '../../model/persons';
/**
 * Generated class for the AllpersonsPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-allpersons',
  templateUrl: 'allpersons.html',
})
export class AllpersonsPage {

  personsList :AngularFireObject<any>
  personsf:personsList={
    key:'',
    name:'',
    sex:'',
    age:'',
    province:'',
    comments:''
  }
  itemArray= [];
  myObject=[];
  myObjectfinal=[];
  searchVal:string;
  private adminLoggedIn :boolean=false;

  constructor(public navCtrl: NavController, 
              public navParams: NavParams,
              public alertCtrl: AlertController ,
              public addpersonsServiceProvider: AddpersonsServiceProvider ,
              public db:AngularFireDatabase) { 


                let adminstatus = localStorage.getItem('adminLoggedIn')
                 console.log(adminstatus)
                if (adminstatus === 'true') {
                  this.adminLoggedIn = true;
                }else{
                  this.adminLoggedIn = false;
                }

                this.personsList=db.object('persons');
               
                this.personsList.snapshotChanges().subscribe(action=>{
               
                  if (action.payload.val()==null || action.payload.val()== undefined) {
                    console.log('No Data')
                  } else {  
               
                this.itemArray.push(action.payload.val() as personsList)
                
                console.log(this.itemArray[0])
                this.myObject = Object.entries(this.itemArray[0])
              
                this.myObjectfinal=this.myObject;
                  }
                })


  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad AllpersonsPage');
  }
  updatepersons1(personsf:personsList){
    this.addpersonsServiceProvider.updatepersons(personsf).then(()=>{
    this.navCtrl.setRoot(HomePage)  
    console.log('update')
  })}
   removepersons(personsf){
      this.addpersonsServiceProvider.removepersons(personsf).then(()=>{
        this.navCtrl.setRoot(HomePage)
        console.log('delete')
      })}

      persond(key,name,sex,age,province,comments){
        this.navCtrl.push(PersondetailsPage,{

          key:key,
          name:name,
          sex:sex,
          age:age,
          province:province,
          comments:comments,
        })
      }

      detailsp(key , name, no, comments){
        let prompt = this.alertCtrl.create({
          title:'التفاصيل',
          message : 'بيانات النزيل',
          inputs:[{name : 'name',
                  value : name},

                  {name : 'no',
                  value : no},

                  {name : 'comments',
                  value : comments},
                 ],
                buttons:[
                {text:'رجوع',
                handler : data =>{
                console.log('cancel clicked');
              }
            },
    
    
          ]
        });
    
       prompt.present();
    
    
      }
      personu(key,name,sex,age,province,comments){
        this.navCtrl.push(PersonupdatePage,{

          key:key,
          name:name,
          sex:sex,
          age:age,
          province:province,
          comments:comments,
        })
      }
  update( key , name ,sex, age ,province, comments ) {
    let prompt = this.alertCtrl.create({
      title: 'تعديل بيانات النزيل',
      inputs: [
        {
          name: 'name',
          value:name
        },
        {
          name: 'sex',
          value: sex
        },
        {

          name: 'age',
          value: age
        },
        {

          name: 'province',
          value: province
        },
        {
          name: 'comments',
          value: comments
        },
      ],
      buttons: [
        {
          text: 'الغاء',
          handler: data => {
            console.log('Cancel clicked');
          }
        },
        {
          text: 'حفظ',
          handler: data => {
        //    console.log('');
             this.personsf.name=data.name
             this.personsf.sex=data.sex
             this.personsf.age=data.age
             this.personsf.province=data.province
             this.personsf.comments=data.comments
             this.personsf.key=key
             this.updatepersons1(this.personsf)
          }
        }
      ]
    });
    prompt.present();
  }



  getItems(ev: any) {
  
        this.myObject=this.myObjectfinal;
        const val = ev.target.value;
        if (val && val.trim() != '') {
        this.myObject= this.myObject.filter((searchbar) => {
        return(searchbar[1]['name'].toLowerCase().indexOf(val.toLowerCase()) > -1)
      })
    }
   }
  }

