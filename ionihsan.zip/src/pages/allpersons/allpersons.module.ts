import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AllpersonsPage } from './allpersons';

@NgModule({
  declarations: [
    AllpersonsPage,
  ],
  imports: [
    IonicPageModule.forChild(AllpersonsPage),
  ],
})
export class AllpersonsPageModule {}
