import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AddpersonsPage } from './addpersons';

@NgModule({
  declarations: [
    AddpersonsPage,
  ],
  imports: [
    IonicPageModule.forChild(AddpersonsPage),
  ],
})
export class AddpersonsPageModule {}
