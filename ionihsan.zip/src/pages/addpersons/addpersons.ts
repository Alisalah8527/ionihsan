import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams , AlertController } from 'ionic-angular';
import { personsList } from '../../model/persons';
import{ AddpersonsServiceProvider }from '../../providers/addpersons-service/addpersons-service'
import { HomePage } from '../home/home';
/**
 * Generated class for the AddpersonsPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-addpersons',
  templateUrl: 'addpersons.html',
})
export class AddpersonsPage {
 
  persons:personsList={
    name:'',
    sex:'',
    age:'',
    province:'',
    comments:'',
  }

  constructor(public navCtrl: NavController, 
              public navParams: NavParams ,
              public addpersonsServiceProvider: AddpersonsServiceProvider,
              public alertCtrl: AlertController) {
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad AddpersonsPage');
  }

  addper(persons:personsList){
   this.addpersonsServiceProvider.addpersons(persons).then(ref=>{
   this.navCtrl.push(HomePage)
   })
  }

  // showAlert() {
  //   const alert = this.alertCtrl.create({
  //     title: 'اضـــافة',
  //     subTitle: 'شكرا لكم لقد تمت عملية الاضافة بنجاح',
  //     buttons: ['OK']
  //   });

  // }
  
  }
