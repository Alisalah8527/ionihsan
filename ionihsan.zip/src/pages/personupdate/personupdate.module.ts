import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { PersonupdatePage } from './personupdate';

@NgModule({
  declarations: [
    PersonupdatePage,
  ],
  imports: [
    IonicPageModule.forChild(PersonupdatePage),
  ],
})
export class PersonupdatePageModule {}
