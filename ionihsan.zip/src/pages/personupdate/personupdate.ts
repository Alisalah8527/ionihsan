import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import {AddpersonsServiceProvider } from '../../providers/addpersons-service/addpersons-service';
import { HomePage } from '../home/home';

/**
 * Generated class for the PersonupdatePage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-personupdate',
  templateUrl: 'personupdate.html',
})
export class PersonupdatePage {
  personu={
    key:'',
    name:'',
    sex:'',
    age:'',
    province:'',
    comments:''
  }

  constructor(public navCtrl: NavController, 
              public navParams: NavParams , 
              public addpersonsServiceProvider: AddpersonsServiceProvider ) {


  this.personu.key=this.navParams.get('key')
  this.personu.name=this.navParams.get('name')
  this.personu.sex=this.navParams.get('sex')
  this.personu.age=this.navParams.get('age')
  this.personu.province=this.navParams.get('province')
  this.personu.comments=this.navParams.get('comments')
  




  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad PersonupdatePage');
  }

  updatepersons1(personsu){
    this.addpersonsServiceProvider.updatepersons(personsu).then(()=>{
    this.navCtrl.setRoot(HomePage)  
    console.log('update')
  })}
  cancel(){
    this.navCtrl.pop();
  }

  updatep(key,name,sex,age,province,comments){
   this.personu.key=key
   this.personu.name=name
   this.personu.sex=sex
   this.personu.age=age
   this.personu.province=province
   this.personu.comments=comments
   console.log(this.personu.key)
   this.updatepersons1(this.personu)
  }


}
