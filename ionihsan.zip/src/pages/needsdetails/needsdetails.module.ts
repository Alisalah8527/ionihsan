import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { NeedsdetailsPage } from './needsdetails';

@NgModule({
  declarations: [
    NeedsdetailsPage,
  ],
  imports: [
    IonicPageModule.forChild(NeedsdetailsPage),
  ],
})
export class NeedsdetailsPageModule {}
