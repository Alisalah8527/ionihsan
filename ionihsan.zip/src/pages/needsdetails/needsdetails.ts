import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';

/**
 * Generated class for the NeedsdetailsPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-needsdetails',
  templateUrl: 'needsdetails.html',
})
export class NeedsdetailsPage {
  needde={
    key:'',
    name:'',
    no:'',
    comments:''
  }
  constructor(public navCtrl: NavController, public navParams: NavParams) {
    this.needde.key=this.navParams.get('key')
    this.needde.name=this.navParams.get('name')
    this.needde.no=this.navParams.get('no')
    this.needde.comments=this.navParams.get('comments')
    console.log(this.needde)
  }


  ionViewDidLoad() {
    console.log('ionViewDidLoad NeedsdetailsPage');
  }

}
