import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { AddneedServiceProvider } from '../../providers/addneed-service/addneed-service';
import { HomePage } from '../home/home';
/**
 * Generated class for the NeedseditPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-needsedit',
  templateUrl: 'needsedit.html',
})
export class NeedseditPage {

  need={
    key:'',
    name:'',
    no:'',
    comments:'',
  }

  constructor(public navCtrl: NavController, 
              public navParams: NavParams ,
              public addneedServiceProvider: AddneedServiceProvider) {


                this.need.key=this.navParams.get('key')
                this.need.name=this.navParams.get('name')
                this.need.no=this.navParams.get('no')
                this.need.comments=this.navParams.get('comments')

  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad NeedseditPage');
  }
  updateneeds(needslist){
    this.addneedServiceProvider.updateneeds(needslist).then(()=>{
    this.navCtrl.setRoot(HomePage)  
    console.log('update')
  })}

  cancel(){
    this.navCtrl.pop();
  }
  updaten(key,name,no,comments){
    this.need.key=key;
    this.need.name=name;
    this.need.no=no;
    this.need.comments=comments;
    this.updateneeds(this.need)
  }













}
