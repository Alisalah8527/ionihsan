import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { NeedseditPage } from './needsedit';

@NgModule({
  declarations: [
    NeedseditPage,
  ],
  imports: [
    IonicPageModule.forChild(NeedseditPage),
  ],
})
export class NeedseditPageModule {}
