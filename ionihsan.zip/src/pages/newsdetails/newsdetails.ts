import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { NewsPage } from '../news/news'

/**
 * Generated class for the NewsdetailsPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-newsdetails',
  templateUrl: 'newsdetails.html',
})
export class NewsdetailsPage {
  detailsn = {
    key : '',
    name : '',
    comments:'',
} 

  constructor(public navCtrl: NavController, 
              public navParams: NavParams) {
                this.detailsn.key=this.navParams.get('key')
                this.detailsn.name=this.navParams.get('name')
                this.detailsn.comments=this.navParams.get('comments')

  }


  ionViewDidLoad() {
    console.log('ionViewDidLoad NewsdetailsPage');
  }
  back(){
    this.navCtrl.setRoot(NewsPage)
  }







}
