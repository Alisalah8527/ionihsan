import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams ,AlertController } from 'ionic-angular';
import { newsList } from '../../model/news';
import {NewsproviderProvider } from '../../providers/newsprovider/newsprovider';
import { HomePage } from '../home/home';
/**
 * Generated class for the AddnewsPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-addnews',
  templateUrl: 'addnews.html',
})
export class AddnewsPage {

  news:newsList={
    name:'',
    comments:''
  }

  constructor(public navCtrl: NavController, 
              public navParams: NavParams,
              public alertCtrl: AlertController,
             public addnewsServiceProvider:NewsproviderProvider) {
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad AddnewsPage');
  }

  addne(news:newsList){
    this.addnewsServiceProvider.addnewss(news).then(ref=>{
    this.showAlert()
    this.navCtrl.push(HomePage)
    })
   }
 
   showAlert() {
     const alert = this.alertCtrl.create({
       title: 'اضافة',
       subTitle: 'شكرا لكم لقد تمت عملية الاضافة بنجاح',
       buttons: ['OK']
     });
 
   }

















}
