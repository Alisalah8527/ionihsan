import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { needsList } from '../../model/needs';
import { AngularFireDatabase } from '../../../node_modules/angularfire2/database';
/*
  Generated class for the AddneedServiceProvider provider.

  See https://angular.io/guide/dependency-injection for more info on providers
  and Angular DI.
*/
@Injectable()
export class AddneedServiceProvider {

  private needslist=this.db.list<needsList>('needs')



  constructor(public db:AngularFireDatabase) {
    console.log('Hello AddpersonsServiceProvider Provider');
  }

getneeds(){
  return this.needslist;
}

addneeds(needslist:needsList){
  return this.needslist.push(needslist);
}
updateneeds(needslist:needsList){
  return this.needslist.update(needslist.key,needslist);
}
removeneeds(needslist){
  return this.needslist.remove(needslist);
}


}
