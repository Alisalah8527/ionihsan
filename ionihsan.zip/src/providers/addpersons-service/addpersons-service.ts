import { Injectable } from '@angular/core';
import { personsList } from '../../model/persons';
import { AngularFireDatabase } from '../../../node_modules/angularfire2/database';
/*
  Generated class for the AddpersonsServiceProvider provider.

  See https://angular.io/guide/dependency-injection for more info on providers
  and Angular DI.
*/
@Injectable()
export class AddpersonsServiceProvider {

    private personslist=this.db.list<personsList>('persons')



  constructor(public db:AngularFireDatabase) {
    console.log('Hello AddpersonsServiceProvider Provider');
  }

getpersons(){
  return this.personslist;
}

addpersons(personslist:personsList){
  return this.personslist.push(personslist);
}
updatepersons(personslist:personsList){
  return this.personslist.update(personslist.key,personslist);
}
removepersons(personslist:personsList){
  return this.personslist.remove(personslist.key);
}




}
