import { Injectable } from '@angular/core';
import { AngularFireDatabase } from '../../../node_modules/angularfire2/database';
import { newsList } from '../../model/news';
/*
  Generated class for the NewsproviderProvider provider.

  See https://angular.io/guide/dependency-injection for more info on providers
  and Angular DI.
*/
@Injectable()
export class NewsproviderProvider {


  private Newslist=this.db.list<newsList>('News')

  constructor(public db:AngularFireDatabase) {
    console.log('Hello NewsproviderProvider Provider');
  }
  addnewss(Newslist:newsList){
    return this.Newslist.push(Newslist);
  }

  removenewss(Newslist:newsList){
    return this.Newslist.remove(Newslist.key);
  }
  updatenews(Newslist:newsList){
    return this.Newslist.update(Newslist.key,Newslist);
  }



}
