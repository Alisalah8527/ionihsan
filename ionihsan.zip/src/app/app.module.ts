import { NgModule, ErrorHandler } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { IonicApp, IonicModule, IonicErrorHandler } from 'ionic-angular';
import { MyApp } from './app.component';
import { AngularFireModule } from 'angularfire2';
import { AngularFireDatabaseModule } from 'angularfire2/database';
import { AngularFireAuthModule } from 'angularfire2/auth';
import { IonicStorageModule } from '@ionic/storage';


import { AboutPage } from '../pages/about/about';
import { ContactPage } from '../pages/contact/contact';
import { HomePage } from '../pages/home/home';
import { TabsPage } from '../pages/tabs/tabs';
import { AllpersonsPage }from '../pages/allpersons/allpersons';
import { AllneedsPage }from'../pages/allneeds/allneeds';
import { NewsPage }from '../pages/news/news';
import { AddneedsPage }from '../pages/addneeds/addneeds';
import { AddpersonsPage }from '../pages/addpersons/addpersons';
import { NeedsdetailsPage } from '../pages/needsdetails/needsdetails';
import { NeedseditPage } from '../pages/needsedit/needsedit';
import {AddnewsPage } from '../pages/addnews/addnews';
import { PersondetailsPage } from '../pages/persondetails/persondetails';
import { PersonupdatePage } from '../pages/personupdate/personupdate';
import { NewsdetailsPage } from '../pages/newsdetails/newsdetails';
import { NewseditPage } from '../pages/newsedit/newsedit';






import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen';
import { AddpersonsServiceProvider } from '../providers/addpersons-service/addpersons-service';
import { AddneedServiceProvider } from '../providers/addneed-service/addneed-service';
import { NewsproviderProvider } from '../providers/newsprovider/newsprovider';



export const firebaseConfig= {
  apiKey: "AIzaSyA1yZi-nVuMLQdSEpLMf9MLY4SwkHROBAE",
  authDomain: "ihsan-ionic.firebaseapp.com",
  databaseURL: "https://ihsan-ionic.firebaseio.com",
  projectId: "ihsan-ionic",
  storageBucket: "ihsan-ionic.appspot.com",
  messagingSenderId: "438037200842"
};

@NgModule({
  declarations: [
    MyApp,
    AboutPage,
    ContactPage,
    HomePage,
    TabsPage,
    AllpersonsPage,
    AllneedsPage,
    NewsPage,
    AddneedsPage,
    AddpersonsPage,
    NeedsdetailsPage,
    NeedseditPage,
    AddnewsPage,
    PersondetailsPage,
    PersonupdatePage,
    NewsdetailsPage,
    NewseditPage
  ],
  imports: [
    BrowserModule,
    IonicModule.forRoot(MyApp),
    AngularFireAuthModule,
    IonicStorageModule.forRoot(),
    AngularFireModule.initializeApp(firebaseConfig),
    AngularFireDatabaseModule,
    
  ],
  bootstrap: [IonicApp],
  entryComponents: [
    MyApp,
    AboutPage,
    ContactPage,
    HomePage,
    TabsPage,
    AllpersonsPage,
    AllneedsPage,
    NewsPage,
    AddneedsPage,
    AddpersonsPage,
    NeedsdetailsPage,
    NeedseditPage,
    AddnewsPage,
    PersondetailsPage,
    PersonupdatePage,
    NewsdetailsPage,
    NewseditPage
  ],
  providers: [
    StatusBar,
    SplashScreen,
    {provide: ErrorHandler, useClass: IonicErrorHandler},
    AddpersonsServiceProvider,
    AddneedServiceProvider,
    NewsproviderProvider
  ]
})
export class AppModule {}
