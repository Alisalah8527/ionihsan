import { Component, ViewChild } from '@angular/core';
import { Nav, Platform,MenuController,AlertController } from 'ionic-angular';
import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen';

import { TabsPage } from '../pages/tabs/tabs';


import { AngularFireAuth } from 'angularfire2/auth';

import { AddpersonsPage } from '../pages/addpersons/addpersons';
import { AddneedsPage } from '../pages/addneeds/addneeds';
import {AddnewsPage } from '../pages/addnews/addnews';



@Component({
  templateUrl: 'app.html'
})
export class MyApp {
  @ViewChild(Nav) navCTRl: Nav;
  navCtrl: Nav;
  rootPage: any = TabsPage;

  pages: Array<{title: string, component: any}>;


  email:string ='';
  password:string = '';
  private adminLoggedIn :boolean=false;

  constructor(public platform: Platform, public statusBar: StatusBar, public splashScreen: SplashScreen,public menuCtrl :MenuController
    ,public fire:AngularFireAuth,public alertCtrl:AlertController) {

      let adminstatus = localStorage.getItem('adminLoggedIn')
      // console.log(adminstatus)
      if (adminstatus === 'true') {
      this.adminLoggedIn = true;
      }else{
      this.adminLoggedIn = false;
     }
     }


  addpe(){
     this.navCTRl.push(AddpersonsPage)
     this.menuCtrl.close();
 
}

addneed(){

  this.navCTRl.push(AddneedsPage)
  this.menuCtrl.close();


}
addnewsa(){

  this.navCTRl.push(AddnewsPage)
  this.menuCtrl.close();


}

logIn(){
  this.fire.auth.signInWithEmailAndPassword(this.email, this.password)
  .then(user =>{
 
  
   if (this.email==='admin@gmail.com') {
     this.adminLoggedIn=true;
     localStorage.setItem('adminLoggedIn','true')
     
     
   }else{
    localStorage.setItem('adminLoggedIn','false')
    this.showAlert()
    this.navCTRl.setRoot(TabsPage)
    this.menuCtrl.close();
   }
   
    this.navCTRl.setRoot(TabsPage)
    this.menuCtrl.close();
  }).catch(error =>{
    console.error(error)
    this.showAlert()
    this.navCTRl.setRoot(TabsPage)
    this.menuCtrl.close();
  })
  
  }

  showAlert() {
    const alert = this.alertCtrl.create({
     
      subTitle: ' لطفا انت لست المسؤول , لست بحاجة لأن تعمل تسجيل دخول يمكنك التصفح بدون تسجيل الدخول',
      buttons: ['OK']
    });
    alert.present();
  }
  logout(){
    localStorage.setItem('adminLoggedIn','false')
    this.fire.auth.signOut().then(user =>{
      this.email=''
      this.password=''
      
      this.adminLoggedIn=false});
    
    localStorage.setItem('adminLoggedIn','false')
    // console.log('adminLoggedIn')
    this.navCTRl.setRoot(TabsPage)
    this.menuCtrl.close();
   
  }

}